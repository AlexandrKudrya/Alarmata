# Sleep Guardian - Project Documentation

> Полная документация проекта умного будильника для Android

---

## 📚 Документы

### 1. [ROADMAP.md](ROADMAP.md) - Дорожная карта разработки
**Что внутри:**
- Разбивка на 5 основных итераций (MVP → Iteration 5)
- 17 под-итераций для работы с Claude Code
- Детальное описание каждой фичи
- Технические задачи для каждого этапа
- Success metrics

**Используй для:**
- Планирования работы
- Понимания последовательности разработки
- Оценки времени на каждый этап

---

### 2. [ARCHITECTURE.md](ARCHITECTURE.md) - Техническая архитектура
**Что внутри:**
- Tech stack и зависимости
- Структура проекта (Clean Architecture + MVVM)
- Детальные примеры кода для ключевых компонентов
- Database schema с Room
- Dependency Injection с Hilt
- Testing strategy (Unit, Integration, UI тесты)
- Performance considerations
- Security best practices

**Используй для:**
- Понимания архитектуры перед началом разработки
- Референса при написании кода
- Настройки проекта

---

### 3. [CI-CD.md](CI-CD.md) - Continuous Integration/Deployment
**Что внутри:**
- GitHub Actions workflows
- Автоматическая сборка APK
- Автоматические тесты при каждом коммите
- Signing configuration для Release APK
- Инструкция по скачиванию APK с телефона
- Telegram уведомления
- Version management
- Troubleshooting

**Используй для:**
- Настройки CI/CD pipeline
- Автоматизации процесса сборки
- Получения готовых APK после каждого коммита

---

## 🚀 Quick Start

### Для начала разработки:

1. **Прочитай ROADMAP.md**
   - Пойми общую структуру
   - Начни с MVP 1.1

2. **Изучи ARCHITECTURE.md**
   - Пойми tech stack
   - Посмотри примеры кода

3. **Настрой CI/CD из CI-CD.md**
   - Создай GitHub репозиторий
   - Добавь workflow файлы
   - Настрой secrets

4. **Начинай с Claude Code:**
   ```
   "Привет Claude Code! Давай начнём с MVP 1.1: Project Setup + Basic UI 
   из роадмапа Sleep Guardian. Создай Android проект с Kotlin + Compose..."
   ```

---

## 📱 Workflow с телефона

1. **Даёшь задачу Claude Code:**
   - "Сделай MVP 1.2 по роадмапу"

2. **Claude Code работает:**
   - Пишет код
   - Коммитит
   - Пушит в GitHub

3. **GitHub Actions:**
   - Запускает тесты
   - Собирает APK
   - Публикует в Releases

4. **Получаешь уведомление в Telegram**
   - Переходишь по ссылке
   - Скачиваешь APK
   - Устанавливаешь и тестируешь

---

## 🎯 Итерации в приоритете

### MVP (Iteration 1) - Самое важное
**Срок:** 3-4 недели

Результат: Базовый функциональный будильник с 3 типами заданий

**Под-итерации:**
1. MVP 1.1 - Project Setup (3-5 дней)
2. MVP 1.2 - CRUD будильников (5-7 дней)
3. MVP 1.3 - Alarm Triggering (5-7 дней)
4. MVP 1.4 - Math Tasks (4-6 дней)
5. MVP 1.5 - QR + Shake Tasks (5-7 дней)

### Iteration 2 - Умные задания
**Срок:** 2-3 недели

Результат: Адаптивные задания, которые не надоедают

### Iteration 3 - Аналитика сна
**Срок:** 2-3 недели

Результат: Понимание паттернов, нормализация режима

### Iteration 4 - Вечерний режим
**Срок:** 2 недели

Результат: Помощь в засыпании, ритуалы

### Iteration 5 - Gamification + AI
**Срок:** 2-3 недели

Результат: Полнофункциональное приложение

---

## 🛠 Tech Stack Overview

**Core:**
- Kotlin 1.9+
- Jetpack Compose
- Material 3

**Architecture:**
- Clean Architecture
- MVVM
- Hilt (DI)
- Room (Database)
- Coroutines + Flow

**System:**
- AlarmManager
- WorkManager
- Foreground Service
- CameraX (QR)
- Sensors API (Shake, Motion)

**Network:**
- Retrofit (Claude API)
- OkHttp

**Визуализация:**
- Vico/MPAndroidChart

**Testing:**
- JUnit 5
- MockK
- Compose Testing

---

## 📊 Success Metrics

**MVP успешен если:**
- ✅ Можешь заменить текущий будильник
- ✅ Невозможно проспать
- ✅ 3 типа заданий работают

**Полный проект успешен если:**
- ✅ Пользуешься постоянно
- ✅ Режим стабилизировался
- ✅ Качество сна улучшилось
- ✅ Мотивация работает долгосрочно

---

## 🎨 Features Highlights

### Core Features (MVP)
- ⏰ Точное срабатывание будильников
- 🔒 Невозможно отключить без задания
- 🧮 Математические задания
- 📱 QR-код сканирование
- 📳 Встряхивание телефона
- 📊 Базовая статистика

### Advanced Features (Post-MVP)
- 🧠 Адаптивная сложность заданий
- 💤 Калькулятор циклов сна
- 📈 Детальная аналитика и инсайты
- 🌙 Вечерний режим с чеклистами
- 🎵 Звуки для сна
- 🏆 Достижения и streaks
- 🤖 AI-powered вопросы (Claude API)
- 📱 Widget для домашнего экрана
- 🔐 Защита от саботажа

---

## 🔧 Development Commands

```bash
# Build debug APK
./gradlew assembleDebug

# Run tests
./gradlew test

# Install on device
./gradlew installDebug

# Run with coverage
./gradlew jacocoTestReport

# Lint check
./gradlew lint

# Clean build
./gradlew clean build
```

---

## 📦 Repository Structure

```
sleep-guardian/
├── app/                    # Main application module
├── docs/                   # This documentation
│   ├── ROADMAP.md
│   ├── ARCHITECTURE.md
│   └── CI-CD.md
├── .github/
│   └── workflows/          # GitHub Actions
│       ├── android-build.yml
│       └── quick-apk.yml
├── gradle/
├── build.gradle.kts
└── README.md
```

---

## 🤝 Working with Claude Code

### Typical Session

```
Ты: "Claude Code, давай сделаем MVP 1.1 из роадмапа Sleep Guardian"

Claude Code: 
- Читает ROADMAP.md и ARCHITECTURE.md
- Создаёт структуру проекта
- Настраивает зависимости
- Создаёт базовые экраны
- Коммитит и пушит

Ты: "Отлично! Теперь давай MVP 1.2"

[... и так далее по роадмапу]
```

### Tips для работы с Claude Code

1. **Ссылайся на документацию:**
   - "Сделай MVP 1.3 по ROADMAP.md"
   - "Используй архитектуру из ARCHITECTURE.md"

2. **Одна под-итерация за раз:**
   - Не пытайся делать всё сразу
   - Завершай под-итерацию полностью

3. **Тестируй после каждой под-итерации:**
   - Скачивай APK
   - Проверяй функциональность
   - Даёшь фидбек Claude Code

4. **Используй CI/CD:**
   - Пуш → автоматические тесты
   - Уверенность в качестве кода

---

## 📞 Support & Feedback

При проблемах:
1. Проверь Troubleshooting в CI-CD.md
2. Посмотри примеры в ARCHITECTURE.md
3. Проверь что следуешь роадмапу

---

## 🎯 Next Steps

1. ✅ Прочитай эти документы
2. ✅ Создай GitHub репозиторий
3. ✅ Настрой CI/CD
4. ✅ Начни MVP 1.1 с Claude Code
5. ✅ Итерируй по роадмапу

**Удачи в разработке! 🚀**

---

## 📝 Version History

- v1.0 (12.02.2026) - Initial documentation
  - ROADMAP.md - 17 под-итераций
  - ARCHITECTURE.md - Полная техническая архитектура
  - CI-CD.md - GitHub Actions setup
